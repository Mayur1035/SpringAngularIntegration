﻿# Components & Installation

## Assumptions: 
- The machine where code is downloaded is equipped with Gcloud CLI
- Gcloud project is created e.g. **project-name**
- Gcloud config is setup to **project-name**
- GAE (Google App Engine) is created in **project-name**

## Angular UI
_Path_: 
```
high-flyers/code/angularui
```
_App Type_: **Angular app**

_Deployment Steps_:
1. Clone the folder to a local path in the workstation.
2. Open a local terminal & run the below command. Note that first time run may take few minutes for successful completion.
```
npm install
```
3. After package installation, run the below command
```
ng build
```
4. Finally, deploy the Angular app to GAE by the below command
```
gcloud app deploy dist/app.yaml
```

## Backend For Frontend
_Path_: 
```
high-flyers/code/esgai
```
_App Type_: **SpringBoot application**

_Deployment Steps_:
1. Deploy app to App Engine standard environment by running mvn command as below
```
$ ./mvnw -DskipTests package appengine:deploy
```
2. Once the application is successfully deployed, test one of the endpoints
```
https://flyers-spring-boot-app-dot-<<projectId>>.ue.r.appspot.com/api/esgreports/keepalive/ping
```
The domain for endpoint can be captured by navigating to the GAE in Console & locating the GAE service **flyers-spring-boot-app-dot**
<br/><br/>
## PDF Uploader
_Path_: 
```
high-flyers/code/cloudRuns/fileuploader
```
_App Type_: **Python dockerized app**

_Deployment Steps_:
1. Clone the folder to a local path in the workstation.
2. Open a local terminal & run the below command
```
gcloud app deploy
```

## Document Parser {Question Extractor}
_Path_: 
```
high-flyers/code/cloudRuns/quesextract
```
_App Type_: **Python dockerized app**

_Deployment Steps_:
1. Clone the folder to a local path in the workstation.
2. Open a local terminal & run the below command
```
gcloud app deploy
```

## PDF Writer
_Path_: 
```
high-flyers/code/cloudRuns/pdfwriter
```
_App Type_: **Python dockerized app**

_Deployment Steps_:
1. Clone the folder to a local path in the workstation.
2. Open a local terminal & run the below command
```
gcloud app deploy
```

## Common
_Path_: 
```
high-flyers/code/cloudRuns/fileretriver
```
_App Type_: **Python dockerized app**

_Deployment Steps_:
1. Clone the folder to a local path in the workstation.
2. Open a local terminal & run the below command
```
gcloud app deploy
```
