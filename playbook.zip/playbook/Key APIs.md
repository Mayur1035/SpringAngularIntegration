﻿# Key APIs

## PDF Uploader - Upload file
API: https://fileuploader-3vj2sth3fq-uc.a.run.app/upload
```
curl --location 'https://fileuploader-3vj2sth3fq-uc.a.run.app/upload' \
--form 'file=@"/C:/Users/ss740/Downloads/Test-2022-annual-report.pdf"' \
--form 'file_type="survey_docs"' \
--form 'year="2030"'
```
<details>
  <summary>View Postman evidence</summary>
<img width="650" alt="image" src="https://github.com/Hackathon2024-March/high-flyers/assets/163707451/a7012620-dc73-4457-a73b-34ef46e1b319">
</details>
<br/>

## Document Parser - Extract Questions from pdf
API: https://quesextract-3vj2sth3fq-uc.a.run.app/extract_question?fileName=Survey-Questionnire-Part1.pdf
```
curl --location --request POST 'https://quesextract-3vj2sth3fq-uc.a.run.app/extract_question?fileName=Survey-Questionnire-Part1.pdf'
```
<details>
  <summary>View Postman evidence</summary>
<img width="650" alt="image" src="https://github.com/Hackathon2024-March/high-flyers/assets/163707451/2e13c5ea-0ab0-441e-9b17-4dca43a59ad1">
</details>
<br/>

## PDF Writer - Create PDF file with the set of extracted questions & ML derived answers
API: https://pdfwriter-3vj2sth3fq-uc.a.run.app/write
```
curl --location 'https://pdfwriter-3vj2sth3fq-uc.a.run.app/write' \
--header 'Content-Type: application/json' \
--data '{
    "taskId" : "adddd1123",
    "year" :"2292",
    "data": [
        {
            "question": "This code responds to requests with our Hello World greeting. HTTP handling is done by a Gunicorn web server in the container. When directly invoked for local use, this code creates a basic web server that listens on the port defined by the PORT environment variable.",
            "ans":"ans"
        },
        {
            "question": "dsfsdf",
            "ans":"dsfsfs"
        }
    ]
}'
```
<details>
  <summary>View Postman evidence</summary>
<img width="650" alt="image" src="https://github.com/Hackathon2024-March/high-flyers/assets/163707451/8bfe66fe-d983-4de5-a696-1e4920679086"/>
<img width="650" alt="image" src="https://github.com/Hackathon2024-March/high-flyers/assets/163707451/e3c4795b-2c34-45c0-9f9b-2a0632d811ab"/>
</details>
<br/>

## Common - Download ML generated PDF file
API: https://fileretriver-3vj2sth3fq-uc.a.run.app/download?file_link=https://storage.cloud.google.com/firstdraftesg/ESG_Survey_adddd1123.pdf
```
curl --location 'https://fileretriver-3vj2sth3fq-uc.a.run.app/download?file_link=https%3A%2F%2Fstorage.cloud.google.com%2Ffirstdraftesg%2FESG_Survey_adddd1123.pdf'
```
<details>
  <summary>View Postman evidence</summary>
<img width="650" alt="image" src="https://github.com/Hackathon2024-March/high-flyers/assets/163707451/0dae3336-2e4f-48ae-a18a-a84c9e74d124"/>
</details>
<br/>

## Common - Get file list 
API: https://fileretriver-3vj2sth3fq-uc.a.run.app/files?year=2030
```
curl --location 'https://fileretriver-3vj2sth3fq-uc.a.run.app/files?year=2030'
```
<details>
  <summary>View Postman evidence</summary>
<img width="650" alt="image" src="https://github.com/Hackathon2024-March/high-flyers/assets/163707451/8133579d-d666-4e7c-bb54-20cd0c85d78f">
</details>
<br/>

## BFF( Backend For Frontend) - APIs List 
Upload the ESG Reports API: https://flyers-spring-boot-app-dot-wellsfargo-genai24-8177.ue.r.appspot.com/api/esgreports/upload
<br/>

Retrieve list all the uploaded ESG reports API: https://flyers-spring-boot-app-dot-wellsfargo-genai24-8177.ue.r.appspot.com/api/esgreports/retrieve
<br/>

Upload the Survey Questionnire API: https://flyers-spring-boot-app-dot-wellsfargo-genai24-8177.ue.r.appspot.com/api/questionnaire/generatefirstdraft/pdf
<br/>

Find status of the Survey Questionnire API: https://flyers-spring-boot-app-dot-wellsfargo-genai24-8177.ue.r.appspot.com/api/questionnaire/generatefirstdraft/pdf/{reportYear}/{TaskId}/status
<br/>

Download the First Draft Report API: https://flyers-spring-boot-app-dot-wellsfargo-genai24-8177.ue.r.appspot.com/api/firstdraftreport/download/result/{year}
<br/>

Retrieve response for the specific question API: https://flyers-spring-boot-app-dot-wellsfargo-genai24-8177.ue.r.appspot.com/api/questionnaire/generatefirstdraft/generateAnswer
<br/>

<details>
  <summary>Download Postman API Collection</summary>
  https://github.com/Hackathon2024-March/high-flyers/blob/main/code/High%20Flyers%20GCP%20ESG%20AI.postman_collection.json
</details>
<br/>

